from flask import Blueprint, jsonify, request
from flask_login import login_required
from services.ai_service import analyse_report
ai_bp = Blueprint("ai", __name__)
@ai_bp.route("/analyse", methods=["POST"])
@login_required
def analyse():
    data = request.get_json(silent=True) or {}
    if not data.get("description"): return jsonify({"error":"description is required"}), 400
    return jsonify(analyse_report(data["description"], data.get("location", "")))
