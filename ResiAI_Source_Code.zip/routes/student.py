import os
from uuid import uuid4
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app import db
from models import Report
from services.ai_service import analyse_report
from services.operations import process_report
student_bp = Blueprint("student", __name__, url_prefix="/student")
def student_only(): return current_user.role == "student"
@student_bp.route("/")
@login_required
def dashboard():
    if not student_only(): return redirect(url_for("management.dashboard"))
    return render_template("student/dashboard.html", reports=Report.query.filter_by(student_id=current_user.id).order_by(Report.created_at.desc()).all())
@student_bp.route("/report", methods=["GET", "POST"])
@login_required
def report_issue():
    if not student_only(): return redirect(url_for("management.dashboard"))
    if request.method == "POST":
        text = request.form.get("description", "").strip()
        if not text: flash("Please describe the issue.", "danger"); return render_template("student/report_issue.html")
        analysis = analyse_report(text, f"Block {current_user.block}, Room {current_user.room}")
        photo = request.files.get("photo"); filename = None
        if photo and photo.filename:
            filename = f"{uuid4().hex}_{secure_filename(photo.filename)}"; photo.save(os.path.join(current_app.config["UPLOAD_FOLDER"], filename))
        report = Report(description=text, photo_filename=filename, student_id=current_user.id, **{k:analysis[k] for k in ("location","category","issue_type","impact","priority","department","recommended_action")}, ai_explanation=analysis["explanation"], confidence=float(analysis["confidence"]))
        db.session.add(report); db.session.flush(); process_report(report); db.session.commit(); flash("Your report was submitted and analysed by ResiAI.", "success"); return redirect(url_for("student.report_detail", report_id=report.id))
    return render_template("student/report_issue.html")
@student_bp.route("/report/<int:report_id>")
@login_required
def report_detail(report_id):
    report = Report.query.get_or_404(report_id)
    if current_user.role == "student" and report.student_id != current_user.id: return redirect(url_for("student.dashboard"))
    return render_template("student/my_report.html", report=report)
