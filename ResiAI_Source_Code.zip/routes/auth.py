from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, current_user
from app import db
from models import User
auth_bp = Blueprint("auth", __name__)
@auth_bp.route("/")
def home(): return redirect(url_for("student.dashboard") if current_user.is_authenticated and current_user.role == "student" else url_for("management.dashboard") if current_user.is_authenticated else url_for("auth.login"))
@auth_bp.route("/login", methods=["GET", "POST"])
@auth_bp.route("/manager/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = User.query.filter_by(email=request.form.get("email", "").lower()).first()
        if user and user.check_password(request.form.get("password", "")):
            login_user(user); return redirect(url_for("management.dashboard") if user.role == "manager" else url_for("student.dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("auth/login.html", manager_login=request.path.startswith("/manager"))
@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        if User.query.filter_by(email=request.form["email"].lower()).first(): flash("That email is already registered.", "danger")
        else:
            user = User(name=request.form["name"], email=request.form["email"].lower(), role="student", block=request.form.get("block"), room=request.form.get("room")); user.set_password(request.form["password"]); db.session.add(user); db.session.commit(); login_user(user); return redirect(url_for("student.dashboard"))
    return render_template("auth/register.html")
@auth_bp.route("/logout")
def logout(): logout_user(); return redirect(url_for("auth.login"))
