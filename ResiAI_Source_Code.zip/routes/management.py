from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user
from app import db
from models import Report, Staff, Prediction, Incident, AIDecision
from services.operations import health_score, save_weekly_health_snapshot, refresh_predictions, prediction_evidence
management_bp = Blueprint("management", __name__, url_prefix="/management")
def manager_only(): return current_user.role == "manager"
@management_bp.route("/")
@login_required
def dashboard():
    if not manager_only(): return redirect(url_for("student.dashboard"))
    refresh_predictions(); save_weekly_health_snapshot(); db.session.commit(); score, explanation = health_score()
    return render_template("management/dashboard.html", score=score, explanation=explanation, reports=Report.query.order_by(Report.created_at.desc()).limit(8).all(), incidents=Incident.query.filter_by(status="Open").all(), decisions=AIDecision.query.order_by(AIDecision.created_at.desc()).limit(6).all(), predictions=Prediction.query.order_by(Prediction.created_at.desc()).all(), staff=Staff.query.all())
@management_bp.route("/reports")
@login_required
def reports(): return render_template("management/reports.html", reports=Report.query.order_by(Report.created_at.desc()).all()) if manager_only() else redirect(url_for("student.dashboard"))
@management_bp.route("/staff")
@login_required
def staff(): return render_template("management/staff.html", staff=Staff.query.all()) if manager_only() else redirect(url_for("student.dashboard"))
@management_bp.route("/predictions")
@login_required
def predictions():
    if not manager_only(): return redirect(url_for("student.dashboard"))
    refresh_predictions(); db.session.commit()
    rows = [{"prediction": p, "evidence": prediction_evidence(p)} for p in Prediction.query.all()]
    return render_template("management/predictions.html", rows=rows)
@management_bp.route("/health")
@login_required
def health():
    if not manager_only(): return redirect(url_for("student.dashboard"))
    snapshot = save_weekly_health_snapshot(); db.session.commit()
    return render_template("management/health.html", snapshot=snapshot)
@management_bp.route("/report/<int:report_id>/status", methods=["POST"])
@login_required
def update_status(report_id):
    if not manager_only(): return redirect(url_for("student.dashboard"))
    report = Report.query.get_or_404(report_id); report.status = request.form.get("status", report.status); db.session.commit(); flash("Report status updated.", "success"); return redirect(url_for("management.reports"))
