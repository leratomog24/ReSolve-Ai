import os
from flask import Flask
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv
from config import Config

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.login_message = "Please sign in to continue."


def create_app(config_class=Config):
    load_dotenv()
    app = Flask(__name__, template_folder="../templates", static_folder="../static")
    app.config.from_object(config_class)
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    db.init_app(app)
    login_manager.init_app(app)
    from models.user import User
    @login_manager.user_loader
    def load_user(user_id): return db.session.get(User, int(user_id))
    from routes.auth import auth_bp
    from routes.student import student_bp
    from routes.management import management_bp
    from routes.ai import ai_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(student_bp)
    app.register_blueprint(management_bp)
    app.register_blueprint(ai_bp, url_prefix="/api")
    with app.app_context():
        db.create_all()
        from services.seed import seed_demo_data
        seed_demo_data()
    return app
