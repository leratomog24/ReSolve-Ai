from app import db
from models import User, Staff, Asset, MaintenanceHistory
from services.operations import refresh_predictions, save_weekly_health_snapshot

def seed_demo_data():
    if User.query.first():
        if not MaintenanceHistory.query.first():
            washer = Asset.query.filter_by(name="Washing Machine A03").first()
            router = Asset.query.filter_by(name="Block B Router").first()
            if washer: db.session.add_all([MaintenanceHistory(asset_id=washer.id, description="Drain pump repaired"), MaintenanceHistory(asset_id=washer.id, description="Door lock replaced")])
            if router: db.session.add(MaintenanceHistory(asset_id=router.id, description="Intermittent signal investigation"))
        refresh_predictions(); save_weekly_health_snapshot(); db.session.commit()
        return
    manager = User(name="Amina Manager", email="manager@resiai.test", role="manager", block="All"); manager.set_password("demo1234")
    student = User(name="Lebo Student", email="student@resiai.test", role="student", block="B", room="204"); student.set_password("demo1234")
    db.session.add_all([manager, student])
    db.session.add_all([Staff(name="Thabo Molefe", email="thabo@resiai.test", department="IT", skills="Wi-Fi, network, router", block="B", active_tasks=1), Staff(name="Nandi Dube", email="nandi@resiai.test", department="Maintenance", skills="Plumbing, electrical, appliances", block="All"), Staff(name="Siphiwe Nkosi", email="sip@resiai.test", department="Security", skills="Safety, access control", block="All"), Staff(name="Maya Patel", email="maya@resiai.test", department="Cleaning", skills="Communal areas", block="A")])
    washer = Asset(name="Washing Machine A03", asset_type="Laundry", location="Block A", recent_failures=5)
    router = Asset(name="Block B Router", asset_type="Network", location="Block B", recent_failures=3)
    boiler = Asset(name="Boiler C01", asset_type="Plumbing", location="Block C", recent_failures=1)
    db.session.add_all([washer, router, boiler]); db.session.flush()
    db.session.add_all([MaintenanceHistory(asset_id=washer.id, description="Drain pump repaired"), MaintenanceHistory(asset_id=washer.id, description="Door lock replaced"), MaintenanceHistory(asset_id=router.id, description="Intermittent signal investigation")])
    refresh_predictions(); save_weekly_health_snapshot(); db.session.commit()
