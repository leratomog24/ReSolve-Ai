from datetime import datetime, timedelta, date
from app import db
from models import Report, Incident, Staff, AIDecision, Notification, Assignment, Asset, Prediction, MaintenanceHistory, ResidenceHealth

PRIORITY = {"Low": 1, "Medium": 2, "High": 3, "Critical": 4}

def match_incident(report):
    recent = Report.query.filter(Report.id != report.id, Report.created_at >= datetime.utcnow()-timedelta(hours=24), Report.category == report.category).all()
    related = [r for r in recent if r.location == report.location and r.status != "Resolved"]
    if len(related) < 1: return None
    incident = next((r.incident for r in related if r.incident and r.incident.status == "Open"), None)
    if not incident:
        incident = Incident(title=f"Possible {report.location} {report.category} incident", category=report.category, location=report.location, priority=report.priority, escalated=report.priority in ("High", "Critical"), explanation="Multiple similar reports in the same location indicate a shared underlying cause.")
        db.session.add(incident); db.session.flush()
        for old in related: old.incident_id = incident.id
    report.incident_id = incident.id
    if PRIORITY[report.priority] > PRIORITY[incident.priority]: incident.priority = report.priority
    return incident

def allocate(report):
    candidates = Staff.query.filter_by(department=report.department, available=True).all()
    if not candidates: return None
    staff = min(candidates, key=lambda s: (s.active_tasks >= s.capacity, s.active_tasks, 0 if s.block in ("All", report.location.replace("Block ", "")) else 1))
    report.assigned_staff_id = staff.id; report.status = "Assigned"; staff.active_tasks += 1
    db.session.add(Assignment(report_id=report.id, staff_id=staff.id))
    return staff

def process_report(report):
    incident = match_incident(report)
    staff = allocate(report)
    if incident:
        db.session.add(AIDecision(report_id=report.id, decision_type="Incident grouping", decision=f"Grouped into incident #{incident.id}", reason=incident.explanation, confidence=.88))
    if staff:
        reason = f"{staff.name} is an available {staff.department} specialist with {staff.active_tasks - 1} active task(s)."
        db.session.add(AIDecision(report_id=report.id, decision_type="Resource allocation", decision=f"Assigned {staff.name}", reason=reason, confidence=.90))
    if report.priority in ("High", "Critical"):
        db.session.add(AIDecision(report_id=report.id, decision_type="Escalation", decision="Escalated to residence management", reason=f"{report.priority} priority and {report.impact} impact require management visibility.", confidence=.92))
    db.session.add(AIDecision(report_id=report.id, decision_type="Report understanding", decision=f"Classified as {report.category} / {report.priority}", reason=report.ai_explanation, confidence=report.confidence))
    db.session.add(Notification(user_id=report.student_id, message=f"Your report has been analysed as {report.priority} priority and is {report.status.lower()}."))
    refresh_predictions()

def _dimension_score(reports, category=None):
    relevant = [r for r in reports if category is None or r.category == category]
    open_items = [r for r in relevant if r.status != "Resolved"]
    penalty = sum(PRIORITY.get(r.priority, 2) * 5 for r in open_items)
    penalty += sum(3 for r in relevant if r.status == "Reported")
    return max(0, min(100, 100 - penalty))


def build_health_snapshot():
    """Creates a reproducible weekly score from captured operational records."""
    since = datetime.utcnow() - timedelta(days=7)
    reports = Report.query.filter(Report.created_at >= since).all()
    open_reports = [r for r in reports if r.status != "Resolved"]
    critical = [r for r in open_reports if r.priority == "Critical"]
    infrastructure = _dimension_score(reports, None)
    wifi = _dimension_score(reports, "Internet")
    maintenance_categories = {"Plumbing", "Electrical", "Laundry", "Furniture", "General"}
    maintenance = _dimension_score([r for r in reports if r.category in maintenance_categories])
    cleanliness = _dimension_score(reports, "Cleaning")
    security = _dimension_score(reports, "Security")
    overall = round((infrastructure + wifi + maintenance + cleanliness + security) / 5)
    target = len([r for r in reports if r.status == "Resolved"])
    drivers = sorted({r.category for r in open_reports if r.priority in ("High", "Critical")})
    explanation = f"Score uses reports captured in the last 7 days: {len(reports)} total, {len(open_reports)} unresolved and {len(critical)} critical. " + (f"Current pressure is concentrated in {', '.join(drivers)}." if drivers else "No high-risk category is currently driving the score.")
    snapshot = ResidenceHealth(period_start=date.today() - timedelta(days=date.today().weekday()), overall_score=overall, infrastructure_score=infrastructure, wifi_score=wifi, maintenance_score=maintenance, cleanliness_score=cleanliness, security_score=security, open_reports=len(open_reports), critical_reports=len(critical), resolved_within_target=target, explanation=explanation)
    return snapshot


def health_score():
    snapshot = build_health_snapshot()
    return snapshot.overall_score, snapshot.explanation


def save_weekly_health_snapshot():
    snapshot = build_health_snapshot()
    existing = ResidenceHealth.query.filter_by(period_start=snapshot.period_start).first()
    if existing:
        for field in ("overall_score", "infrastructure_score", "wifi_score", "maintenance_score", "cleanliness_score", "security_score", "open_reports", "critical_reports", "resolved_within_target", "explanation"): setattr(existing, field, getattr(snapshot, field))
        return existing
    db.session.add(snapshot)
    return snapshot

def refresh_predictions():
    for asset in Asset.query.all():
        history_count = MaintenanceHistory.query.filter_by(asset_id=asset.id).count()
        category = {"Network": "Internet", "Laundry": "Laundry", "Plumbing": "Plumbing"}.get(asset.asset_type, "General")
        recent_reports = Report.query.filter(Report.category == category, Report.location == asset.location, Report.created_at >= datetime.utcnow()-timedelta(days=30)).count()
        risk_points = asset.recent_failures * 2 + history_count + recent_reports
        risk = "High" if risk_points >= 8 else "Medium" if risk_points >= 4 else "Low"
        recommendation = f"Schedule preventative inspection for {asset.name}; risk is based on {asset.recent_failures} recorded failures, {history_count} maintenance record(s), and {recent_reports} related report(s) in the last 30 days."
        prediction = Prediction.query.filter_by(asset_id=asset.id).first()
        if prediction: prediction.risk, prediction.recommendation = risk, recommendation
        else: db.session.add(Prediction(asset_id=asset.id, risk=risk, recommendation=recommendation))


def prediction_evidence(prediction):
    asset = prediction.asset
    category = {"Network": "Internet", "Laundry": "Laundry", "Plumbing": "Plumbing"}.get(asset.asset_type, "General")
    return {"failures": asset.recent_failures, "maintenance_records": MaintenanceHistory.query.filter_by(asset_id=asset.id).count(), "related_reports_30_days": Report.query.filter(Report.category == category, Report.location == asset.location, Report.created_at >= datetime.utcnow()-timedelta(days=30)).count()}
