import json, re
from flask import current_app

SYSTEM_PROMPT = """You are ResiAI. Return ONLY JSON with category, location, priority, issue_type, impact, department, recommended_action, explanation, confidence. Categories: Internet, Plumbing, Laundry, Electrical, Security, Cleaning, Furniture, General. Priorities: Critical, High, Medium, Low."""

def _fallback(text, default_location=""):
    value = text.lower()
    rules = [(("wifi", "wi-fi", "internet", "network", "router"), "Internet", "IT", "Service outage", "High", "Academic", "Inspect network infrastructure and restore connectivity."), (("leak", "flood", "water", "pipe", "toilet"), "Plumbing", "Maintenance", "Leak", "High", "Safety", "Dispatch a plumbing technician and inspect for water damage."), (("electric", "spark", "power", "socket", "shock"), "Electrical", "Maintenance", "Electrical fault", "Critical", "Safety", "Isolate the area and dispatch an electrician immediately."), (("security", "break", "intruder", "unsafe", "lock"), "Security", "Security", "Security concern", "Critical", "Safety", "Alert security and investigate immediately."), (("wash", "laundry", "dryer"), "Laundry", "Maintenance", "Broken appliance", "Medium", "Convenience", "Inspect and repair the appliance."), (("dirty", "clean", "rubbish", "trash"), "Cleaning", "Cleaning", "Cleanliness issue", "Medium", "Residence-wide", "Schedule a cleaning response.")]
    category, department, issue, priority, impact, action = "General", "Maintenance", "General fault", "Medium", "Convenience", "Inspect the reported issue."
    for words, category, department, issue, priority, impact, action in rules:
        if any(word in value for word in words): break
    if any(word in value for word in ("fire", "smoke", "flood", "shock", "gas")): priority, impact = "Critical", "Safety"
    if any(word in value for word in ("assignment", "exam", "everyone", "whole block", "since yesterday")) and priority == "Medium": priority, impact = "High", "Academic"
    match = re.search(r"(?:block|building)\s*([a-z0-9]+)|room\s*(\d+)", value, re.I)
    location = default_location or "Residence"
    if match: location = "Block " + match.group(1) if match.group(1) else "Room " + match.group(2)
    return {"category":category,"location":location,"priority":priority,"issue_type":issue,"impact":impact,"department":department,"recommended_action":action,"explanation":f"Detected {category.lower()} indicators and {impact.lower()} impact in the student's report.","confidence":0.82}

def analyse_report(text, default_location=""):
    key = current_app.config.get("GEMINI_API_KEY")
    if key:
        try:
            from google import genai
            client = genai.Client(api_key=key)
            response = client.models.generate_content(model=current_app.config["GEMINI_MODEL"], contents=f"{SYSTEM_PROMPT}\nDefault location: {default_location}\nReport: {text}")
            data = json.loads(response.text.replace("```json", "").replace("```", "").strip())
            return {**_fallback(text, default_location), **data}
        except Exception: current_app.logger.exception("Gemini failed; using local rules")
    return _fallback(text, default_location)
