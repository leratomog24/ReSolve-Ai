# ResiAI

Flask prototype for AI-powered student accommodation operations. It includes student reporting, Gemini-backed analysis (with a safety-rule fallback), incident grouping, staff allocation, escalation, predictive maintenance and an AI Operations Centre.

## Run locally

1. Create and activate a virtual environment, then install the packages in `requirements.txt` and `requirements-gemini.txt`.
2. Set `GEMINI_API_KEY` in `.env` (optional; the app still works using local rules without it).
3. Run `flask --app run run`.

The default database is SQLite. Set `DATABASE_URL` to a MySQL SQLAlchemy URI for MySQL, for example `mysql+pymysql://user:password@localhost/resiai`.

Demo accounts: `student@resiai.test` and `manager@resiai.test`, each with password `demo1234`.
