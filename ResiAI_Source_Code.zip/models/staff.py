from app import db


class Staff(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True)
    department = db.Column(db.String(40), nullable=False)
    skills = db.Column(db.String(255), default="")
    block = db.Column(db.String(40), default="All")
    active_tasks = db.Column(db.Integer, default=0)
    capacity = db.Column(db.Integer, default=4)
    available = db.Column(db.Boolean, default=True)
