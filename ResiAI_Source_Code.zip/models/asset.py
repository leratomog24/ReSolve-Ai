from datetime import datetime
from app import db

class Asset(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False); asset_type = db.Column(db.String(60)); location = db.Column(db.String(120))
    recent_failures = db.Column(db.Integer, default=0); last_serviced = db.Column(db.Date)
class MaintenanceHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True); asset_id = db.Column(db.Integer, db.ForeignKey("asset.id"), nullable=False)
    description = db.Column(db.Text); occurred_at = db.Column(db.DateTime, default=datetime.utcnow)
class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True); asset_id = db.Column(db.Integer, db.ForeignKey("asset.id"), nullable=False)
    risk = db.Column(db.String(20), nullable=False); recommendation = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow); asset = db.relationship("Asset")


class ResidenceHealth(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    period_start = db.Column(db.Date, nullable=False, unique=True)
    overall_score = db.Column(db.Integer, nullable=False)
    infrastructure_score = db.Column(db.Integer, nullable=False)
    wifi_score = db.Column(db.Integer, nullable=False)
    maintenance_score = db.Column(db.Integer, nullable=False)
    cleanliness_score = db.Column(db.Integer, nullable=False)
    security_score = db.Column(db.Integer, nullable=False)
    open_reports = db.Column(db.Integer, default=0)
    critical_reports = db.Column(db.Integer, default=0)
    resolved_within_target = db.Column(db.Integer, default=0)
    explanation = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
