from datetime import datetime
from app import db


class Incident(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(180), nullable=False); category = db.Column(db.String(40)); location = db.Column(db.String(120))
    priority = db.Column(db.String(20), default="Medium"); status = db.Column(db.String(30), default="Open")
    escalated = db.Column(db.Boolean, default=False); explanation = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    reports = db.relationship("Report", backref="incident", lazy=True)
