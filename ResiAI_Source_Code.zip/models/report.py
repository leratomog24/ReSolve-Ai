from datetime import datetime
from app import db


class Report(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.Text, nullable=False)
    photo_filename = db.Column(db.String(255)); location = db.Column(db.String(120))
    category = db.Column(db.String(40)); issue_type = db.Column(db.String(80)); impact = db.Column(db.String(80))
    priority = db.Column(db.String(20), default="Medium"); department = db.Column(db.String(40))
    recommended_action = db.Column(db.Text); ai_explanation = db.Column(db.Text); confidence = db.Column(db.Float)
    status = db.Column(db.String(30), default="Reported")
    student_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    incident_id = db.Column(db.Integer, db.ForeignKey("incident.id")); assigned_staff_id = db.Column(db.Integer, db.ForeignKey("staff.id"))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    assigned_staff = db.relationship("Staff", foreign_keys=[assigned_staff_id])


class Assignment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    report_id = db.Column(db.Integer, db.ForeignKey("report.id"), nullable=False)
    staff_id = db.Column(db.Integer, db.ForeignKey("staff.id"), nullable=False)
    status = db.Column(db.String(30), default="Assigned")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
