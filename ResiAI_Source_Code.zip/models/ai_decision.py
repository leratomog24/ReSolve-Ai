from datetime import datetime
from app import db

class AIDecision(db.Model):
    id = db.Column(db.Integer, primary_key=True); report_id = db.Column(db.Integer, db.ForeignKey("report.id"))
    decision_type = db.Column(db.String(60), nullable=False); decision = db.Column(db.Text, nullable=False)
    reason = db.Column(db.Text, nullable=False); confidence = db.Column(db.Float); created_at = db.Column(db.DateTime, default=datetime.utcnow)
    report = db.relationship("Report")
class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True); user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    message = db.Column(db.Text, nullable=False); read = db.Column(db.Boolean, default=False); created_at = db.Column(db.DateTime, default=datetime.utcnow)
